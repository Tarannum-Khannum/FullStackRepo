import { configureStore, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { CollectionItem, CollectionList, Product } from '../types';

const getSaved = <T,>(key: string, fallback: T): T => {
  try {
    if (typeof localStorage === 'undefined') return fallback;
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
};

const persist = (key: string, value: unknown) => {
  if (typeof localStorage !== 'undefined') localStorage.setItem(key, JSON.stringify(value));
};

type UserState = {
  owned: CollectionItem[];
  wishlist: Product[];
  selling: CollectionItem[];
  savedPosts: number[];
  likedPosts: number[];
  darkMode: boolean;
};

const initialState: UserState = getSaved('collectors-hub', {
  owned: [],
  wishlist: [],
  selling: [],
  savedPosts: [],
  likedPosts: [],
  darkMode: false,
});

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    addOwned: (state, action: PayloadAction<Product>) => {
      if (!state.owned.some(({ id }) => id === action.payload.id)) {
        state.owned.push({
          ...action.payload,
          addedAt: new Date().toISOString(),
          estimatedValue: action.payload.price,
        });
      }
    },
    addWishlist: (state, action: PayloadAction<Product>) => {
      if (!state.wishlist.some(({ id }) => id === action.payload.id)) {
        state.wishlist.push(action.payload);
      }
    },
    addSelling: (state, action: PayloadAction<Product>) => {
      if (!state.selling.some(({ id }) => id === action.payload.id)) {
        state.selling.push({
          ...action.payload,
          addedAt: new Date().toISOString(),
          estimatedValue: action.payload.price,
        });
      }
    },
    remove: (state, action: PayloadAction<{ id: number; list: CollectionList }>) => {
      (state[action.payload.list] as Product[]) = (
        state[action.payload.list] as Product[]
      ).filter(({ id }) => id !== action.payload.id);
    },
    move: (
      state,
      action: PayloadAction<{ id: number; from: CollectionList; to: CollectionList }>
    ) => {
      const { id, from, to } = action.payload;
      const item = (state[from] as Product[]).find(x => x.id === id);
      if (!item) return;
      if ((state[to] as Product[]).some(x => x.id === id)) return;
      (state[from] as Product[]) = (state[from] as Product[]).filter(x => x.id !== id);
      if (to === 'wishlist') {
        state.wishlist.push(item as Product);
      } else {
        (state[to] as CollectionItem[]).push({
          ...(item as Product),
          addedAt: new Date().toISOString(),
          estimatedValue:
            'estimatedValue' in item ? (item as CollectionItem).estimatedValue : item.price,
        });
      }
    },
    toggleSaved: (state, action: PayloadAction<number>) => {
      state.savedPosts = state.savedPosts.includes(action.payload)
        ? state.savedPosts.filter(id => id !== action.payload)
        : [...state.savedPosts, action.payload];
    },
    toggleLiked: (state, action: PayloadAction<number>) => {
      state.likedPosts = state.likedPosts.includes(action.payload)
        ? state.likedPosts.filter(id => id !== action.payload)
        : [...state.likedPosts, action.payload];
    },
    toggleTheme: state => {
      state.darkMode = !state.darkMode;
    },
  },
});

export const {
  addOwned,
  addSelling,
  addWishlist,
  remove,
  move,
  toggleSaved,
  toggleLiked,
  toggleTheme,
} = userSlice.actions;

export const userReducer = userSlice.reducer;

export const store = configureStore({
  reducer: { user: userSlice.reducer },
  middleware: getDefault =>
    getDefault().concat(
      () => next => action => {
        const result = next(action);
        persist('collectors-hub', store.getState().user);
        return result;
      }
    ),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
