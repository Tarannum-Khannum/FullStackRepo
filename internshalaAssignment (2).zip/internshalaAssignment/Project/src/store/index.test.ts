import { describe, expect, it } from 'vitest';
import { addOwned, addSelling, addWishlist, move, remove, toggleLiked, toggleSaved, userReducer } from './index';
import type { Product } from '../types';

const item: Product = {
  id: 1,
  title: 'Test piece',
  category: 'Art',
  condition: 'Mint',
  price: 100,
  seller: 'Test',
  location: 'Here',
  image: '',
  description: '',
  specifications: {},
};

describe('collector state', () => {
  it('does not duplicate owned items', () => {
    const once = userReducer(undefined, addOwned(item));
    expect(userReducer(once, addOwned(item)).owned).toHaveLength(1);
  });

  it('does not duplicate wishlist items', () => {
    const once = userReducer(undefined, addWishlist(item));
    expect(userReducer(once, addWishlist(item)).wishlist).toHaveLength(1);
  });

  it('does not duplicate selling items', () => {
    const once = userReducer(undefined, addSelling(item));
    expect(userReducer(once, addSelling(item)).selling).toHaveLength(1);
  });

  it('tracks wishlist and saved posts', () => {
    const state = userReducer(undefined, addWishlist(item));
    expect(state.wishlist).toHaveLength(1);
    expect(userReducer(state, toggleSaved(9)).savedPosts).toEqual([9]);
  });

  it('toggles saved posts off', () => {
    const with9 = userReducer(undefined, toggleSaved(9));
    expect(userReducer(with9, toggleSaved(9)).savedPosts).toEqual([]);
  });

  it('toggles liked posts and persists', () => {
    const liked = userReducer(undefined, toggleLiked(3));
    expect(liked.likedPosts).toEqual([3]);
    expect(userReducer(liked, toggleLiked(3)).likedPosts).toEqual([]);
  });

  it('removes an item from owned', () => {
    const with1 = userReducer(undefined, addOwned(item));
    expect(userReducer(with1, remove({ id: 1, list: 'owned' })).owned).toHaveLength(0);
  });

  it('moves an item from owned to selling', () => {
    const with1 = userReducer(undefined, addOwned(item));
    const moved = userReducer(with1, move({ id: 1, from: 'owned', to: 'selling' }));
    expect(moved.owned).toHaveLength(0);
    expect(moved.selling).toHaveLength(1);
  });

  it('moves an item from wishlist to owned', () => {
    const with1 = userReducer(undefined, addWishlist(item));
    const moved = userReducer(with1, move({ id: 1, from: 'wishlist', to: 'owned' }));
    expect(moved.wishlist).toHaveLength(0);
    expect(moved.owned).toHaveLength(1);
  });

  it('does not move to a list that already contains the item', () => {
    let state = userReducer(undefined, addOwned(item));
    state = userReducer(state, addSelling(item));
    const unchanged = userReducer(state, move({ id: 1, from: 'owned', to: 'selling' }));
    expect(unchanged.owned).toHaveLength(1);
    expect(unchanged.selling).toHaveLength(1);
  });
});
