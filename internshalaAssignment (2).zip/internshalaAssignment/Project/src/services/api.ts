import axios from 'axios';
import type { Post, Product } from '../types';
const client = axios.create({ baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:3001', timeout: 5000 });
export const api = { products: () => client.get<Product[]>('/products').then(r => r.data), product: (id: string) => client.get<Product>(`/products/${id}`).then(r => r.data), posts: () => client.get<Post[]>('/posts').then(r => r.data), post: (id: string) => client.get<Post>(`/posts/${id}`).then(r => r.data) };
