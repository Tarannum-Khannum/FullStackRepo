import { StrictMode, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider, useSelector } from 'react-redux';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import {
  Box,
  Button,
  CircularProgress,
  CssBaseline,
  ThemeProvider,
  createTheme,
} from '@mui/material';
import { store, type RootState } from './store';
import { Header } from './components/Header';
import { Marketplace } from './components/Marketplace';
import { Community } from './components/Community';
import { Collection } from './components/Collection';
import { ProductDetails, PostDetails } from './components/Details';
import { Empty, Page } from './components/shared';
import './styles.css';

function NotFound() {
  return (
    <Page title="Lost in the archive">
      <Empty text="We couldn't find that page" />
      <Button component={Link} to="/" variant="contained">
        Explore marketplace
      </Button>
    </Page>
  );
}

function App() {
  const dark = useSelector((s: RootState) => s.user.darkMode);

  const theme = createTheme({
    palette: {
      mode: dark ? 'dark' : 'light',
      primary: { main: '#4f46e5' },
      secondary: { main: '#f59e0b' },
      background: { default: dark ? '#10111b' : '#f8f8fc' },
    },
    typography: {
      fontFamily: 'Inter, system-ui, sans-serif',
      h3: { fontWeight: 800 },
    },
    shape: { borderRadius: 16 },
  });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Header />
      <Suspense
        fallback={
          <Box p={6} textAlign="center">
            <CircularProgress />
          </Box>
        }
      >
        <Routes>
          <Route path="/" element={<Marketplace />} />
          <Route path="/community" element={<Community />} />
          <Route path="/collection" element={<Collection />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          <Route path="/post/:id" element={<PostDetails />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
      <Box
        component="footer"
        sx={{
          borderTop: 1,
          borderColor: 'divider',
          py: 3,
          textAlign: 'center',
          color: 'text.secondary',
        }}
      >
        Collector&apos;s Hub · Built for people who keep stories.
      </Box>
    </ThemeProvider>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </StrictMode>
);
