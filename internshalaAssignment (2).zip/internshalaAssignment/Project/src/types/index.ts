export type Condition = 'Mint' | 'Excellent' | 'Good' | 'Fair';

export type Product = {
  id: number;
  title: string;
  category: string;
  condition: Condition;
  price: number;
  seller: string;
  location: string;
  image: string;
  description: string;
  specifications: Record<string, string>;
};

export type Post = {
  id: number;
  username: string;
  avatar: string;
  timestamp: string;
  image: string;
  caption: string;
  category: string;
  likes: number;
  comments: number;
  productId: number;
};

export type CollectionItem = Product & { addedAt: string; estimatedValue: number };

export type CollectionList = 'owned' | 'wishlist' | 'selling';
