import {
  Card,
  CardActions,
  CardContent,
  Chip,
  IconButton,
  Stack,
  Typography,
  Button,
} from '@mui/material';
import { Heart, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { addOwned, addWishlist, type RootState } from '../store';
import type { Product } from '../types';
import { currency, ItemImage } from './shared';

export function ProductCard({
  product,
  compact = false,
  onDuplicate,
}: {
  product: Product;
  compact?: boolean;
  onDuplicate?: (msg: string) => void;
}) {
  const dispatch = useDispatch();
  const wishlist = useSelector((s: RootState) => s.user.wishlist);
  const owned = useSelector((s: RootState) => s.user.owned);
  const navigate = useNavigate();

  const inWishlist = wishlist.some(x => x.id === product.id);
  const inOwned = owned.some(x => x.id === product.id);

  const handleAddOwned = () => {
    if (inOwned) {
      onDuplicate?.('Already in your collection.');
    } else {
      dispatch(addOwned(product));
    }
  };

  const handleAddWishlist = () => {
    if (inWishlist) {
      onDuplicate?.('Already on your wishlist.');
    } else {
      dispatch(addWishlist(product));
    }
  };

  return (
    <Card component={motion.div} whileHover={{ y: -4 }} className="card">
      <ItemImage src={product.image} alt={product.title} />
      <CardContent>
        <Stack direction="row" justifyContent="space-between" gap={1}>
          <Chip label={product.category} size="small" />
          <Chip label={product.condition} size="small" color="warning" variant="outlined" />
        </Stack>
        <Typography variant="h6" mt={1} noWrap>
          {product.title}
        </Typography>
        <Typography variant="h6" color="primary">
          {currency(product.price)}
        </Typography>
        {!compact && (
          <Typography variant="body2" color="text.secondary">
            {product.seller} · {product.location}
          </Typography>
        )}
      </CardContent>
      <CardActions>
        <Button size="small" onClick={() => navigate(`/product/${product.id}`)}>
          Details
        </Button>
        <IconButton
          aria-label="Add to collection"
          color={inOwned ? 'success' : 'default'}
          onClick={handleAddOwned}
        >
          <ShoppingBag size={18} />
        </IconButton>
        <IconButton
          aria-label="Add to wishlist"
          color={inWishlist ? 'error' : 'default'}
          onClick={handleAddWishlist}
        >
          <Heart size={18} fill={inWishlist ? 'currentColor' : 'none'} />
        </IconButton>
      </CardActions>
    </Card>
  );
}
