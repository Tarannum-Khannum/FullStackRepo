import {
  Alert,
  Box,
  Button,
  Chip,
  Container,
  Divider,
  Skeleton,
  Snackbar,
  Stack,
  Typography,
} from '@mui/material';
import { ArrowLeft, MapPin } from 'lucide-react';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { addOwned, addWishlist, type RootState } from '../store';
import { api } from '../services/api';
import { useData } from '../hooks/useData';
import { CardGrid, ItemImage, Page, currency } from './shared';
import { ProductCard } from './ProductCard';
import { CommunityCard } from './Community';

export function ProductDetails() {
  const { id = '' } = useParams();
  const { data: product, loading, error, retry } = useData(() => api.product(id));
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const owned = useSelector((s: RootState) => s.user.owned);
  const wishlist = useSelector((s: RootState) => s.user.wishlist);
  const { data: allProducts = [] } = useData(api.products);
  const [snack, setSnack] = useState('');

  if (loading)
    return (
      <Container sx={{ py: 6 }}>
        <Skeleton height={500} variant="rounded" />
      </Container>
    );

  if (error || !product)
    return (
      <Page title="Item unavailable">
        <Alert severity="error" action={<Button onClick={retry}>Retry</Button>}>
          This listing could not be found.
        </Alert>
      </Page>
    );

  const related = allProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddOwned = () => {
    if (owned.some(x => x.id === product.id)) {
      setSnack('Already in your collection.');
    } else {
      dispatch(addOwned(product));
    }
  };

  const handleAddWishlist = () => {
    if (wishlist.some(x => x.id === product.id)) {
      setSnack('Already on your wishlist.');
    } else {
      dispatch(addWishlist(product));
    }
  };

  return (
    <Page title={product.title} subtitle={`${product.seller} · ${product.location}`}>
      <Button startIcon={<ArrowLeft size={17} />} onClick={() => navigate(-1)} sx={{ mb: 2 }}>
        Back
      </Button>

      <Stack direction={{ xs: 'column', md: 'row' }} spacing={4}>
        <Box flex={1}>
          <ItemImage src={product.image} alt={product.title} height={440} />
        </Box>
        <Box flex={1}>
          <Stack direction="row" spacing={1}>
            <Chip label={product.category} />
            <Chip label={product.condition} color="warning" />
          </Stack>
          <Typography variant="h3" mt={2}>
            {currency(product.price)}
          </Typography>
          <Typography color="text.secondary" mt={2}>
            {product.description}
          </Typography>
          <Typography variant="h6" mt={3}>
            Specifications
          </Typography>
          {Object.entries(product.specifications).map(([k, v]) => (
            <Stack key={k} direction="row" justifyContent="space-between" py={0.7}>
              <Typography color="text.secondary">{k}</Typography>
              <Typography fontWeight={600}>{v}</Typography>
            </Stack>
          ))}
          <Divider sx={{ my: 2 }} />
          <Typography fontWeight={700}>{product.seller}</Typography>
          <Typography color="text.secondary">
            <MapPin size={15} /> {product.location}
          </Typography>
          <Stack direction="row" spacing={1} mt={3}>
            <Button variant="contained" onClick={handleAddOwned}>
              Add to collection
            </Button>
            <Button variant="outlined" onClick={handleAddWishlist}>
              Add to wishlist
            </Button>
          </Stack>
        </Box>
      </Stack>

      {related.length > 0 && (
        <>
          <Typography variant="h5" mt={6} mb={2}>
            Related discoveries
          </Typography>
          <CardGrid>
            {related.map(p => (
              <ProductCard
                key={p.id}
                product={p}
                compact
                onDuplicate={msg => setSnack(msg)}
              />
            ))}
          </CardGrid>
        </>
      )}

      <Snackbar
        open={!!snack}
        autoHideDuration={2500}
        onClose={() => setSnack('')}
        message={snack}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Page>
  );
}

export function PostDetails() {
  const { id = '' } = useParams();
  const { data, loading, error, retry } = useData(() => api.post(id));

  if (loading)
    return (
      <Page title="Post">
        <Skeleton height={420} />
      </Page>
    );

  if (error || !data)
    return (
      <Page title="Post unavailable">
        <Alert severity="error" action={<Button onClick={retry}>Retry</Button>}>
          This post is no longer available.
        </Alert>
      </Page>
    );

  return (
    <Page title="Community post">
      <CommunityCard post={data} />
    </Page>
  );
}
