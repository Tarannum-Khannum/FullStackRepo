import { useState } from 'react';
import {
  Button,
  Card,
  CardActions,
  CardContent,
  Chip,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  Snackbar,
  Stack,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import { Search, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { move, remove, type RootState } from '../store';
import type { CollectionItem, CollectionList, Product } from '../types';
import { CATEGORIES, CONDITIONS, CardGrid, Empty, ItemImage, Page, currency } from './shared';

function CollectionCard({
  item,
  list,
  onDuplicate,
}: {
  item: Product & Partial<CollectionItem>;
  list: CollectionList;
  onDuplicate: (msg: string) => void;
}) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const state = useSelector((s: RootState) => s.user);

  const moveTargets: CollectionList[] =
    list === 'owned'
      ? ['selling', 'wishlist']
      : list === 'wishlist'
        ? ['owned', 'selling']
        : ['owned', 'wishlist'];

  const handleMove = (to: CollectionList) => {
    const alreadyThere = (state[to] as { id: number }[]).some(x => x.id === item.id);
    if (alreadyThere) {
      onDuplicate(`Already in ${to}.`);
      return;
    }
    dispatch(move({ id: item.id, from: list, to }));
  };

  return (
    <Card className="card">
      <ItemImage src={item.image} alt={item.title} />
      <CardContent>
        <Chip size="small" label={item.category} />
        <Typography variant="h6" mt={1}>
          {item.title}
        </Typography>
        <Typography color="primary" fontWeight={700}>
          {currency(item.estimatedValue ?? item.price)} estimated value
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Added{' '}
          {item.addedAt
            ? formatDistanceToNow(new Date(item.addedAt), { addSuffix: true })
            : 'to wishlist'}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={() => navigate(`/product/${item.id}`)}>
          View details
        </Button>
        <IconButton aria-label="Remove" onClick={() => dispatch(remove({ id: item.id, list }))}>
          <Trash2 size={18} />
        </IconButton>
        {moveTargets.map(to => (
          <Button key={to} size="small" onClick={() => handleMove(to)}>
            Move to {to}
          </Button>
        ))}
      </CardActions>
    </Card>
  );
}

export function Collection() {
  const state = useSelector((s: RootState) => s.user);
  const [tab, setTab] = useState<CollectionList>('owned');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [condition, setCondition] = useState('All');
  const [sort, setSort] = useState('added-desc');
  const [snack, setSnack] = useState('');

  const items = (state[tab] as (Product & Partial<CollectionItem>)[])
    .filter(
      x =>
        x.title.toLowerCase().includes(query.toLowerCase()) &&
        (category === 'All' || x.category === category) &&
        (condition === 'All' || x.condition === condition)
    )
    .slice()
    .sort((a, b) => {
      if (sort === 'price-asc') return a.price - b.price;
      if (sort === 'price-desc') return b.price - a.price;
      if (sort === 'title') return a.title.localeCompare(b.title);
      if (sort === 'added-asc')
        return new Date(a.addedAt ?? 0).getTime() - new Date(b.addedAt ?? 0).getTime();
      // added-desc (default)
      return new Date(b.addedAt ?? 0).getTime() - new Date(a.addedAt ?? 0).getTime();
    });

  return (
    <Page
      title="My collection"
      subtitle="The pieces that tell your story."
      action={<Chip label={`${state.owned.length} owned`} color="primary" />}
    >
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab value="owned" label={`Owned (${state.owned.length})`} />
        <Tab value="wishlist" label={`Wishlist (${state.wishlist.length})`} />
        <Tab value="selling" label={`Selling (${state.selling.length})`} />
      </Tabs>

      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={1.5}
        mb={3}
        flexWrap="wrap"
      >
        <TextField
          size="small"
          sx={{ flex: 1, minWidth: 180 }}
          placeholder="Search your collection"
          value={query}
          onChange={e => setQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search size={18} />
              </InputAdornment>
            ),
          }}
        />
        <Select size="small" value={category} onChange={e => setCategory(e.target.value)}>
          {CATEGORIES.map(x => (
            <MenuItem key={x} value={x}>
              {x}
            </MenuItem>
          ))}
        </Select>
        <Select size="small" value={condition} onChange={e => setCondition(e.target.value)}>
          {CONDITIONS.map(x => (
            <MenuItem key={x} value={x}>
              {x}
            </MenuItem>
          ))}
        </Select>
        <Select size="small" value={sort} onChange={e => setSort(e.target.value)}>
          <MenuItem value="added-desc">Newest added</MenuItem>
          <MenuItem value="added-asc">Oldest added</MenuItem>
          <MenuItem value="price-asc">Price: Low to High</MenuItem>
          <MenuItem value="price-desc">Price: High to Low</MenuItem>
          <MenuItem value="title">Title A–Z</MenuItem>
        </Select>
      </Stack>

      <CardGrid>
        {items.map(item => (
          <CollectionCard
            key={item.id}
            item={item}
            list={tab}
            onDuplicate={msg => setSnack(msg)}
          />
        ))}
      </CardGrid>

      {!items.length && <Empty text={`Your ${tab} is empty`} />}

      <Snackbar
        open={!!snack}
        autoHideDuration={2500}
        onClose={() => setSnack('')}
        message={snack}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Page>
  );
}
