import { useState } from 'react';
import {
  Alert,
  Button,
  Chip,
  InputAdornment,
  MenuItem,
  Select,
  Skeleton,
  Snackbar,
  Stack,
  TextField,
} from '@mui/material';
import { Search } from 'lucide-react';
import { api } from '../services/api';
import { useData, useDebounce } from '../hooks/useData';
import { CATEGORIES, CONDITIONS, CardGrid, Empty, Page } from './shared';
import { ProductCard } from './ProductCard';

export function Marketplace() {
  const { data = [], loading, error, retry } = useData(api.products);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [condition, setCondition] = useState('All');
  const [sort, setSort] = useState('featured');
  const [snack, setSnack] = useState('');

  const debouncedQuery = useDebounce(query, 300);

  const products = data
    .filter(
      p =>
        `${p.title} ${p.seller}`.toLowerCase().includes(debouncedQuery.toLowerCase()) &&
        (category === 'All' || p.category === category) &&
        (condition === 'All' || p.condition === condition)
    )
    .sort((a, b) => {
      if (sort === 'low') return a.price - b.price;
      if (sort === 'high') return b.price - a.price;
      if (sort === 'newest') return b.id - a.id;
      return a.id - b.id; // featured
    });

  return (
    <Page
      title="Discover remarkable finds"
      subtitle="Curated objects worth keeping."
      action={<Chip color="secondary" label={`${data.length} listings`} />}
    >
      {error ? (
        <Alert severity="error" action={<Button onClick={retry}>Retry</Button>}>
          We couldn&apos;t load the marketplace.
        </Alert>
      ) : (
        <>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} mb={3} flexWrap="wrap">
            <TextField
              size="small"
              placeholder="Search collectibles"
              value={query}
              onChange={e => setQuery(e.target.value)}
              sx={{ flex: 1, minWidth: 180 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search size={18} />
                  </InputAdornment>
                ),
              }}
            />
            <Select
              size="small"
              value={category}
              onChange={e => setCategory(e.target.value)}
            >
              {CATEGORIES.map(x => (
                <MenuItem key={x} value={x}>
                  {x}
                </MenuItem>
              ))}
            </Select>
            <Select
              size="small"
              value={condition}
              onChange={e => setCondition(e.target.value)}
            >
              {CONDITIONS.map(x => (
                <MenuItem key={x} value={x}>
                  {x}
                </MenuItem>
              ))}
            </Select>
            <Select size="small" value={sort} onChange={e => setSort(e.target.value)}>
              <MenuItem value="featured">Featured</MenuItem>
              <MenuItem value="newest">Newest</MenuItem>
              <MenuItem value="low">Price: Low to High</MenuItem>
              <MenuItem value="high">Price: High to Low</MenuItem>
            </Select>
          </Stack>

          <CardGrid>
            {loading
              ? Array.from({ length: 8 }, (_, i) => (
                  <Skeleton key={i} variant="rounded" height={320} />
                ))
              : products.map(p => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    onDuplicate={msg => setSnack(msg)}
                  />
                ))}
          </CardGrid>

          {!loading && !products.length && <Empty text="No collectibles found" />}
        </>
      )}

      <Snackbar
        open={!!snack}
        autoHideDuration={2500}
        onClose={() => setSnack('')}
        message={snack}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Page>
  );
}
