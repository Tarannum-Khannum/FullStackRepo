import { type ReactNode } from 'react';
import {
  Box,
  CardMedia,
  Container,
  Stack,
  Typography,
} from '@mui/material';
import { PackageOpen } from 'lucide-react';

export const CATEGORIES = ['All', 'Trading Cards', 'Watches', 'Comics', 'Art', 'Figures'];
export const CONDITIONS = ['All', 'Mint', 'Excellent', 'Good', 'Fair'];

export const currency = (value: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(value);

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80';

export function ItemImage({
  src,
  alt,
  height = 190,
}: {
  src: string;
  alt: string;
  height?: number;
}) {
  return (
    <CardMedia
      component="img"
      height={height}
      image={src}
      alt={alt}
      onError={e => {
        e.currentTarget.src = FALLBACK_IMAGE;
      }}
      loading="lazy"
    />
  );
}

export function Empty({ text }: { text: string }) {
  return (
    <Box sx={{ textAlign: 'center', py: 8 }}>
      <PackageOpen size={48} />
      <Typography variant="h6" mt={2}>
        {text}
      </Typography>
      <Typography color="text.secondary">
        Try adjusting your filters or explore the marketplace.
      </Typography>
    </Box>
  );
}

export function Page({
  title,
  subtitle,
  children,
  action,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <Container maxWidth="lg" sx={{ py: { xs: 3, md: 5 } }}>
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="start"
        mb={3}
      >
        <Box>
          <Typography variant="h3" className="page-title">
            {title}
          </Typography>
          {subtitle && (
            <Typography color="text.secondary" mt={0.5}>
              {subtitle}
            </Typography>
          )}
        </Box>
        {action}
      </Stack>
      {children}
    </Container>
  );
}

export function CardGrid({ children }: { children: ReactNode }) {
  return (
    <Box
      display="grid"
      gridTemplateColumns="repeat(auto-fill,minmax(240px,1fr))"
      gap={2.5}
    >
      {children}
    </Box>
  );
}
