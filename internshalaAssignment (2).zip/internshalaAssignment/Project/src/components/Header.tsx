import { useState } from 'react';
import {
  AppBar,
  Box,
  Button,
  Drawer,
  IconButton,
  Stack,
  Toolbar,
  Typography,
} from '@mui/material';
import { Menu, Moon, ShoppingBag, Sun } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toggleTheme, type RootState } from '../store';

const NAV_LINKS: [string, string][] = [
  ['/', 'Marketplace'],
  ['/community', 'Community'],
  ['/collection', 'My Collection'],
];

export function Header() {
  const dispatch = useDispatch();
  const dark = useSelector((s: RootState) => s.user.darkMode);
  const [open, setOpen] = useState(false);

  const nav = (
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={1}>
      {NAV_LINKS.map(([to, label]) => (
        <Button
          key={to}
          component={NavLink}
          to={to}
          onClick={() => setOpen(false)}
          color="inherit"
        >
          {label}
        </Button>
      ))}
    </Stack>
  );

  return (
    <AppBar position="sticky" elevation={0}>
      <Toolbar>
        <ShoppingBag size={24} />
        <Typography variant="h6" sx={{ ml: 1, fontWeight: 800, flexGrow: 1 }}>
          Collector&apos;s Hub
        </Typography>
        <Box sx={{ display: { xs: 'none', md: 'block' } }}>{nav}</Box>
        <IconButton color="inherit" onClick={() => dispatch(toggleTheme())}>
          {dark ? <Sun /> : <Moon />}
        </IconButton>
        <IconButton
          color="inherit"
          sx={{ display: { md: 'none' } }}
          onClick={() => setOpen(true)}
        >
          <Menu />
        </IconButton>
      </Toolbar>
      <Drawer anchor="right" open={open} onClose={() => setOpen(false)}>
        <Box sx={{ p: 3, width: 240 }}>{nav}</Box>
      </Drawer>
    </AppBar>
  );
}
