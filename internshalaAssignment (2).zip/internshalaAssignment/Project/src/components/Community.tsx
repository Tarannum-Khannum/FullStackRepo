import { useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  Skeleton,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { Bookmark, Heart, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { toggleLiked, toggleSaved, type RootState } from '../store';
import type { Post } from '../types';
import { api } from '../services/api';
import { useData, useDebounce } from '../hooks/useData';
import { CATEGORIES, Empty, ItemImage, Page } from './shared';

function CommunityCard({ post }: { post: Post }) {
  const dispatch = useDispatch();
  const saved = useSelector((s: RootState) => s.user.savedPosts.includes(post.id));
  const liked = useSelector((s: RootState) => s.user.likedPosts.includes(post.id));
  const navigate = useNavigate();

  // Optimistic like count: base from data + delta from persisted liked state
  const displayLikes = liked ? post.likes + 1 : post.likes;

  return (
    <Card component={motion.div} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <CardContent>
        <Stack direction="row" alignItems="center" spacing={1.5}>
          <img className="avatar" src={post.avatar} alt={post.username} />
          <Box flexGrow={1}>
            <Typography fontWeight={700}>{post.username}</Typography>
            <Typography variant="caption" color="text.secondary">
              {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })} ·{' '}
              {post.category}
            </Typography>
          </Box>
          <IconButton
            onClick={() => dispatch(toggleSaved(post.id))}
            color={saved ? 'primary' : 'default'}
            aria-label={saved ? 'Unsave post' : 'Save post'}
          >
            <Bookmark size={19} fill={saved ? 'currentColor' : 'none'} />
          </IconButton>
        </Stack>
        <Typography my={2}>{post.caption}</Typography>
      </CardContent>
      <ItemImage src={post.image} alt={post.caption} height={340} />
      <CardActions sx={{ px: 2, pb: 2 }}>
        <Button
          startIcon={<Heart size={17} fill={liked ? 'currentColor' : 'none'} />}
          color={liked ? 'error' : 'inherit'}
          onClick={() => dispatch(toggleLiked(post.id))}
        >
          {displayLikes}
        </Button>
        <Button onClick={() => navigate(`/post/${post.id}`)}>{post.comments} comments</Button>
        <Button sx={{ ml: 'auto' }} onClick={() => navigate(`/product/${post.productId}`)}>
          Open item
        </Button>
      </CardActions>
    </Card>
  );
}

export { CommunityCard };

export function Community() {
  const { data = [], loading, error, retry } = useData(api.posts);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');

  const debouncedQuery = useDebounce(query, 300);

  const posts = data.filter(
    p =>
      (p.username + p.caption).toLowerCase().includes(debouncedQuery.toLowerCase()) &&
      (category === 'All' || p.category === category)
  );

  return (
    <Page
      title="The collector community"
      subtitle="Stories, displays, and knowledge from people who care."
    >
      {error ? (
        <Alert severity="error" action={<Button onClick={retry}>Retry</Button>}>
          The community is taking a short break.
        </Alert>
      ) : (
        <>
          <Stack direction={{ xs: 'column', sm: 'row' }} mb={3} spacing={1.5}>
            <TextField
              size="small"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search posts"
              sx={{ flex: 1 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search size={18} />
                  </InputAdornment>
                ),
              }}
            />
            <Select
              size="small"
              value={category}
              onChange={e => setCategory(e.target.value)}
            >
              {CATEGORIES.map(x => (
                <MenuItem value={x} key={x}>
                  {x}
                </MenuItem>
              ))}
            </Select>
          </Stack>

          <Stack spacing={2}>
            {loading
              ? Array.from({ length: 4 }, (_, i) => (
                  <Skeleton key={i} height={300} variant="rounded" />
                ))
              : posts.map(p => <CommunityCard post={p} key={p.id} />)}
          </Stack>

          {!loading && !posts.length && <Empty text="No conversations found" />}
        </>
      )}
    </Page>
  );
}
